from .tigerasm import *

__doc__ = tigerasm.__doc__
if hasattr(tigerasm, "__all__"):
    __all__ = tigerasm.__all__